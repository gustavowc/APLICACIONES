// Export pages
export '/home_page/home_page_widget.dart' show HomePageWidget;
export '/crear_cuenta/crear_cuenta_widget.dart' show CrearCuentaWidget;
export '/add_nota/add_nota_widget.dart' show AddNotaWidget;
export '/home_notes/home_notes_widget.dart' show HomeNotesWidget;
export '/nota/nota_widget.dart' show NotaWidget;
export '/log_in_create_cuenta/log_in_create_cuenta_widget.dart'
    show LogInCreateCuentaWidget;
export '/codigo_q_r/codigo_q_r_widget.dart' show CodigoQRWidget;
export '/mapa/mapa_widget.dart' show MapaWidget;
