package com.mycompany.notas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
