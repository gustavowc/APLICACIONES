package com.example.flutter_flashlight_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
